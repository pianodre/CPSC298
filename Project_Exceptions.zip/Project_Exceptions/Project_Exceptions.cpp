#include <iostream>
#include <stdexcept>
#include <string>

using namespace std;

unsigned long sigma(unsigned long n) {
    // Precondition check
    if (n < 1) {
        throw runtime_error("Precondition error in " + string(__FILE__) + " at line " + to_string(__LINE__) + ": n = " + to_string(n));
    }

    // Compute the sum using a for loop
    unsigned long sum = 0;
    for (unsigned long i = 1; i <= n; ++i) {
        sum += i;
    }

    // Post-condition check
    unsigned long expected_sum = n * (n + 1) / 2;
    if (sum != expected_sum) {
        throw runtime_error("Postcondition error in " + string(__FILE__) + " at line " + to_string(__LINE__) + ": sum = " + to_string(sum));
    }

    return sum;
}

int main() {
    try {
        cout << "sigma(5) = " << sigma(5) << endl;
    } catch (const exception &e) {
        cerr << e.what() << endl;
    }

    try {
        cout << "sigma(0) = " << sigma(0) << endl; // This should trigger the precondition exception
    } catch (const exception &e) {
        cerr << e.what() << endl;
    }

    // Injecting a fault: Change the condition of the for loop
    // This is just for demonstration, to show how to handle the post-condition failure
    try {
        // Temporary incorrect loop condition for demonstration
        unsigned long sum = 0;
        for (unsigned long i = 1; i < 5; ++i) { // i < n instead of i <= n
            sum += i;
        }
        unsigned long expected_sum = 5 * (5 + 1) / 2;
        if (sum != expected_sum) {
            throw runtime_error("Postcondition error in " + string(__FILE__) + " at line " + to_string(__LINE__) + ": sum = " + to_string(sum));
        }
        cout << "Temporary incorrect sigma(5) = " << sum << endl;
    } catch (const exception &e) {
        cerr << e.what() << endl;
    }

    return 0;
}
